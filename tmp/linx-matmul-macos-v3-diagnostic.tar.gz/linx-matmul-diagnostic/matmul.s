	.text
	.file	"matmul.cpp"
	.section	.text._ZN3pto18layout_type_to_strENS_10LayoutEnumE,"ax",@progbits
	.globl	_ZN3pto18layout_type_to_strENS_10LayoutEnumE // -- Begin function _ZN3pto18layout_type_to_strENS_10LayoutEnumE
	.p2align	1
	.type	_ZN3pto18layout_type_to_strENS_10LayoutEnumE,@function
_ZN3pto18layout_type_to_strENS_10LayoutEnumE: // @_ZN3pto18layout_type_to_strENS_10LayoutEnumE
.LBB0_0:                                // %entry
	L.BSTART.STD	COND, .LBB0_2
.Ltmp0:
	addtpc	%tpcrel_hi(.L.str.3), 	->a1
	c.movi	2, 	->t
	setc.ltu	t#1, a0
.LBB0_1:                                // %switch.lookup
	L.BSTART.STD	DIRECT, .LBB0_3
.Ltmp1:
	addtpc	%tpcrel_hi(.Lswitch.table._ZN3pto18layout_type_to_strENS_10LayoutEnumE), 	->t
	addi	t#1, %tpcrel_lo(.Ltmp1), 	->t
	ld	[t#1, a0<<3], 	->a0
.LBB0_2:
	C.BSTART.STD	
	addi	a1, %tpcrel_lo(.Ltmp0), 	->a0
.LBB0_3:                                // %return
	C.BSTART.STD	RET
	c.setc.tgt	ra
	C.BSTART.STD	
.Lfunc_end0:
	.size	_ZN3pto18layout_type_to_strENS_10LayoutEnumE, .Lfunc_end0-_ZN3pto18layout_type_to_strENS_10LayoutEnumE
                                        // -- End function
	.section	.text._Z15writeBinaryFilePKcPKhm,"ax",@progbits
	.globl	_Z15writeBinaryFilePKcPKhm      // -- Begin function _Z15writeBinaryFilePKcPKhm
	.p2align	1
	.type	_Z15writeBinaryFilePKcPKhm,@function
_Z15writeBinaryFilePKcPKhm:             // @_Z15writeBinaryFilePKcPKhm
.LBB1_1:                                // %entry
	C.BSTART.STD	RET
	c.movi	1, 	->a0
	c.setc.tgt	ra
	C.BSTART.STD	
.Lfunc_end1:
	.size	_Z15writeBinaryFilePKcPKhm, .Lfunc_end1-_Z15writeBinaryFilePKcPKhm
                                        // -- End function
	.section	.text._Z14readBinaryFilePKcPhm,"ax",@progbits
	.globl	_Z14readBinaryFilePKcPhm        // -- Begin function _Z14readBinaryFilePKcPhm
	.p2align	1
	.type	_Z14readBinaryFilePKcPhm,@function
_Z14readBinaryFilePKcPhm:               // @_Z14readBinaryFilePKcPhm
.LBB2_1:                                // %entry
	C.BSTART.STD	RET
	c.movi	1, 	->a0
	c.setc.tgt	ra
	C.BSTART.STD	
.Lfunc_end2:
	.size	_Z14readBinaryFilePKcPhm, .Lfunc_end2-_Z14readBinaryFilePKcPhm
                                        // -- End function
	.section	.text.main,"ax",@progbits
	.globl	main                            // -- Begin function main
	.p2align	1
	.type	main,@function
main:                                   // @main
	.cfi_startproc
.LBB3_0:                                // %entry
	FENTRY	[ra ~ ra], sp!, 32760
.LBB3_8:                                // %entry
	.cfi_def_cfa_offset 32760
	.cfi_offset ra, -8
	C.BSTART.STD	
.LBB3_1:                                // %entry
	C.BSTART.STD	
	lui	-209, 	->t
	addi	t#1, 3832, 	->t
	add	sp, t#1, 	->sp
	.cfi_def_cfa_offset 884992
.LBB3_2:                                // %entry
	C.BSTART.STD	
	lui	1, 	->u
	lui	144, 	->t
	addi	t#1, 248, 	->t
	c.add	sp, t#1, ->t
	c.add	t#1, u#1, ->t
	bic	t#1, 0, 12, 	->a1
	lui	72, 	->t
	addi	t#1, 248, 	->t
	c.add	sp, t#1, ->t
	c.add	t#1, u#1, ->t
	bic	t#1, 0, 12, 	->a2
	addi	sp, 248, 	->t
	c.add	t#1, u#1, ->t
	bic	t#1, 0, 12, 	->a0
.LBB3_3:                                // %entry
	//APP
	B.HINT TRACE.begin

	//NO_APP
.LBB3_4:                                // %entry
	L.BSTART.STD	CALL, _Z18matmul_multithreadIfLi64ELi256ELi256ELi32ELi32ELi32EEvPfPT_S2_
	setret	.Ltmp2, ->ra
.Ltmp2:
.LBB3_5:                                // %entry
	//APP
	B.HINT TRACE.end

	//NO_APP
.LBB3_6:                                // %entry
	C.BSTART.STD	
	c.movr	zero, 	->a0
                                        // implicit-def: $r10
                                        // implicit-def: $r10
	lui	208, 	->t
	addi	t#1, 264, 	->t
	add	sp, t#1, 	->sp
.LBB3_7:                                // %entry
	FRET.STK	[ra ~ ra], sp!, 32760
	C.BSTART.STD	
.Lfunc_end3:
	.size	main, .Lfunc_end3-main
	.cfi_endproc
                                        // -- End function
	.section	.text._Z18matmul_multithreadIfLi64ELi256ELi256ELi32ELi32ELi32EEvPfPT_S2_,"axG",@progbits,_Z18matmul_multithreadIfLi64ELi256ELi256ELi32ELi32ELi32EEvPfPT_S2_,comdat
	.weak	_Z18matmul_multithreadIfLi64ELi256ELi256ELi32ELi32ELi32EEvPfPT_S2_ // -- Begin function _Z18matmul_multithreadIfLi64ELi256ELi256ELi32ELi32ELi32EEvPfPT_S2_
	.p2align	1
	.type	_Z18matmul_multithreadIfLi64ELi256ELi256ELi32ELi32ELi32EEvPfPT_S2_,@function
_Z18matmul_multithreadIfLi64ELi256ELi256ELi32ELi32ELi32EEvPfPT_S2_: // @_Z18matmul_multithreadIfLi64ELi256ELi256ELi32ELi32ELi32EEvPfPT_S2_
	.cfi_startproc
.LBB4_0:                                // %entry
	FENTRY	[s0 ~ s8], sp!, 256
.LBB4_34:                               // %entry
	.cfi_def_cfa_offset 256
	.cfi_offset s0, -8
	.cfi_offset s1, -16
	.cfi_offset s2, -24
	.cfi_offset s3, -32
	.cfi_offset s4, -40
	.cfi_offset s5, -48
	.cfi_offset s6, -56
	.cfi_offset s7, -64
	.cfi_offset s8, -72
	C.BSTART.STD	
.LBB4_1:                                // %entry
	C.BSTART.STD	
	c.movr	a2, 	->u
	ssrget	2050, 	->u
	lui	262143, 	->t
	c.slli	t#1, 4, ->t
	and	t#1, u#1<<16, 	->t
	c.add	a1, t#1, ->t
	sdi	t#1, [sp, 176]                  // 8-byte Folded Spill
	lui	56, 	->t
	c.add	a2, t#1, ->t
	sdi	t#1, [sp, 168]                  // 8-byte Folded Spill
	lui	48, 	->t
	add	a2, t#1, 	->a3
	lui	40, 	->t
	add	a2, t#1, 	->a4
	lui	32, 	->t
	add	a2, t#1, 	->a5
	lui	24, 	->t
	add	a2, t#1, 	->a6
	lui	16, 	->t
	add	a2, t#1, 	->a7
	lui	8, 	->t
	add	a2, t#1, 	->x0
	bic	u#1, 18, 46, 	->t
	add	a0, t#1<<16, 	->t
	sdi	t#1, [sp, 160]                  // 8-byte Folded Spill
	c.movi	1, 	->a1
	c.movr	zero, 	->a0
.LBB4_2:                                // %for.cond6.preheader
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB4_3 Depth 2
	C.BSTART.STD	
	sdi	a1, [sp, 152]                   // 8-byte Folded Spill
	ldi	[sp, 176], 	->t             // 8-byte Folded Reload
	add	t#1, a0<<2, 	->s0
	addi	s0, 896, 	->s1
	addi	s0, 128, 	->s2
	addi	s0, 256, 	->s3
	addi	s0, 384, 	->s4
	addi	s0, 512, 	->s5
	addi	s0, 640, 	->s6
	addi	s0, 768, 	->s7
	ldi	[sp, 160], 	->a1            // 8-byte Folded Reload
	add	a1, a0<<2, 	->s8
	c.movr	zero, 	->a0
.LBB4_3:                                // %for.body9
                                        //   Parent Loop BB4_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	C.BSTART.STD	
	add	a2, a0, 	->a1
	addi	zero, 32, 	->x1
	addi	zero, 1024, 	->x2
.LBB4_4:                                // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[s0,x2],[]

	//NO_APP
.LBB4_5:                                // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->t<16KB>
	B.IOR	[a1,x2],[]

	//NO_APP
.LBB4_6:                                // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TMOV.L2S.PUBLISH, FP32
	C.B.IOS	
	B.IOT	t#1, mask=1111, TSize=6, last

	//NO_APP
.LBB4_7:                                // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.CUBE	TMATMUL, FP32
	B.DATR	FP32, byte0, Null
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	B.DIM	x1, 0, 	->lb2
	C.B.IOS	
	B.IOT	u#1, mask=1111
	B.IOT	mask=1111, last, 	->t<16KB>

	//NO_APP
.LBB4_8:                                // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	C.BSTART.STD	
	add	x0, a0, 	->a1
.LBB4_9:                                // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[s2,x2],[]

	//NO_APP
.LBB4_10:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[a1,x2],[]

	//NO_APP
.LBB4_11:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	C.BSTART.STD	
	add	a7, a0, 	->a1
.LBB4_12:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[s3,x2],[]

	//NO_APP
.LBB4_13:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[a1,x2],[]

	//NO_APP
.LBB4_14:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	C.BSTART.STD	
	add	a6, a0, 	->a1
.LBB4_15:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[s4,x2],[]

	//NO_APP
.LBB4_16:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[a1,x2],[]

	//NO_APP
.LBB4_17:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	C.BSTART.STD	
	add	a5, a0, 	->a1
.LBB4_18:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[s5,x2],[]

	//NO_APP
.LBB4_19:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[a1,x2],[]

	//NO_APP
.LBB4_20:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	C.BSTART.STD	
	add	a4, a0, 	->a1
.LBB4_21:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[s6,x2],[]

	//NO_APP
.LBB4_22:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[a1,x2],[]

	//NO_APP
.LBB4_23:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	C.BSTART.STD	
	add	a3, a0, 	->a1
.LBB4_24:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[s7,x2],[]

	//NO_APP
.LBB4_25:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[a1,x2],[]

	//NO_APP
.LBB4_26:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	C.BSTART.STD	
	ldi	[sp, 168], 	->t             // 8-byte Folded Reload
	add	t#1, a0, 	->a1
.LBB4_27:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[s1,x2],[]

	//NO_APP
.LBB4_28:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TLOAD, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	mask=1111, last, 	->u<16KB>
	B.IOR	[a1,x2],[]

	//NO_APP
.LBB4_29:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	C.BSTART.STD	
	add	s8, a0, 	->a1
.LBB4_30:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	//APP
	BSTART.TLSU	TSTORE, FP32
	B.DIM	x1, 0, 	->lb0
	B.DIM	x1, 0, 	->lb1
	C.B.DIMI	32, 	->lb2
	B.IOT	t#1, mask=1111, last
	B.IOR	[a1,x2],[]

	//NO_APP
.LBB4_31:                               // %for.body9
                                        //   in Loop: Header=BB4_3 Depth=2
	L.BSTART.STD	COND, .LBB4_3
	addi	a0, 128, 	->a0
	setc.nei	a0, 1024
.LBB4_32:                               // %for.cond.cleanup8
                                        //   in Loop: Header=BB4_2 Depth=1
	L.BSTART.STD	COND, .LBB4_2
	lui	2, 	->a0
	ldi	[sp, 152], 	->t             // 8-byte Folded Reload
	setc.andi	t#1, 1
	c.movr	zero, 	->a1
.LBB4_33:                               // %for.cond.cleanup
	FRET.RA	[s0 ~ s8], sp!, 256
	C.BSTART.STD	
.Lfunc_end4:
	.size	_Z18matmul_multithreadIfLi64ELi256ELi256ELi32ELi32ELi32EEvPfPT_S2_, .Lfunc_end4-_Z18matmul_multithreadIfLi64ELi256ELi256ELi32ELi32ELi32EEvPfPT_S2_
	.cfi_endproc
                                        // -- End function
	.section	.text.startup,"axG",@progbits,_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE,comdat
	.p2align	1                               // -- Begin function __cxx_global_var_init
	.type	__cxx_global_var_init,@function
__cxx_global_var_init:                  // @__cxx_global_var_init
.LBB5_0:                                // %entry
	L.BSTART.STD	COND, .LBB5_2
.Ltmp3:
	addtpc	%tpcrel_hi(_ZGVN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE), 	->t
	lbui	[t#1, %tpcrel_lo(.Ltmp3)], 	->t
	c.setc.ne	t#1, zero
.LBB5_1:                                // %init.check
	C.BSTART.STD	
.Ltmp5:
	addtpc	%tpcrel_hi(_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE), 	->t
	c.movi	1, 	->t
	sdi.u	t#1, [t#2, %tpcrel_lo(.Ltmp5)]
	addi	t#2, %tpcrel_lo(.Ltmp5), 	->t
	swi	zero, [t#1, 8]
	swi	zero, [t#1, 12]
	swi	zero, [t#1, 16]
.Ltmp4:
	addtpc	%tpcrel_hi(_ZGVN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE), 	->t
	sbi	t#3, [t#1, %tpcrel_lo(.Ltmp4)]
.LBB5_2:                                // %init.end
	C.BSTART.STD	RET
	c.setc.tgt	ra
	C.BSTART.STD	
.Lfunc_end5:
	.size	__cxx_global_var_init, .Lfunc_end5-__cxx_global_var_init
                                        // -- End function
	.section	.text.startup,"axG",@progbits,_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE,comdat
	.p2align	1                               // -- Begin function __cxx_global_var_init.4
	.type	__cxx_global_var_init.4,@function
__cxx_global_var_init.4:                // @__cxx_global_var_init.4
.LBB6_0:                                // %entry
	L.BSTART.STD	COND, .LBB6_2
.Ltmp6:
	addtpc	%tpcrel_hi(_ZGVN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE), 	->t
	lbui	[t#1, %tpcrel_lo(.Ltmp6)], 	->t
	c.setc.ne	t#1, zero
.LBB6_1:                                // %init.check
	C.BSTART.STD	
.Ltmp8:
	addtpc	%tpcrel_hi(_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE), 	->t
	c.movi	1, 	->t
	sdi.u	t#1, [t#2, %tpcrel_lo(.Ltmp8)]
	addi	t#2, %tpcrel_lo(.Ltmp8), 	->t
	swi	zero, [t#1, 8]
	swi	zero, [t#1, 12]
	swi	zero, [t#1, 16]
.Ltmp7:
	addtpc	%tpcrel_hi(_ZGVN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE), 	->t
	sbi	t#3, [t#1, %tpcrel_lo(.Ltmp7)]
.LBB6_2:                                // %init.end
	C.BSTART.STD	RET
	c.setc.tgt	ra
	C.BSTART.STD	
.Lfunc_end6:
	.size	__cxx_global_var_init.4, .Lfunc_end6-__cxx_global_var_init.4
                                        // -- End function
	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.8,"aMS",@progbits,1
	.p2align	3
.L.str:
	.asciz	"RowMajor"
	.size	.L.str, 9

	.type	.L.str.1,@object                // @.str.1
	.p2align	3
.L.str.1:
	.asciz	"ColMajor"
	.size	.L.str.1, 9

	.type	.L.str.2,@object                // @.str.2
	.p2align	3
.L.str.2:
	.asciz	"kNoneBox"
	.size	.L.str.2, 9

	.type	.L.str.3,@object                // @.str.3
	.p2align	3
.L.str.3:
	.asciz	"UnsupportedLayout"
	.size	.L.str.3, 18

	.type	_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE,@object // @_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE
	.section	.bss._ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE,"aGw",@nobits,_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE,comdat
	.weak	_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE
	.p2align	3
_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE:
	.zero	20
	.size	_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE, 20

	.type	_ZGVN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE,@object // @_ZGVN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE
	.section	.sbss,"aw",@nobits
	.weak	_ZGVN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE
	.p2align	3
_ZGVN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE:
	.quad	0                               // 0x0
	.size	_ZGVN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE, 8

	.type	_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE,@object // @_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE
	.section	.bss._ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE,"aGw",@nobits,_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE,comdat
	.weak	_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE
	.p2align	3
_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE:
	.zero	20
	.size	_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE, 20

	.type	_ZGVN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE,@object // @_ZGVN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE
	.section	.sbss,"aw",@nobits
	.weak	_ZGVN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE
	.p2align	3
_ZGVN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE:
	.quad	0                               // 0x0
	.size	_ZGVN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE, 8

	.section	.init_array,"aGw",@init_array,_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE,comdat
	.p2align	3
	.quad	__cxx_global_var_init
	.section	.init_array,"aGw",@init_array,_ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE,comdat
	.p2align	3
	.quad	__cxx_global_var_init.4
	.type	.Lswitch.table._ZN3pto18layout_type_to_strENS_10LayoutEnumE,@object // @switch.table._ZN3pto18layout_type_to_strENS_10LayoutEnumE
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3
.Lswitch.table._ZN3pto18layout_type_to_strENS_10LayoutEnumE:
	.quad	.L.str.2
	.quad	.L.str
	.quad	.L.str.1
	.size	.Lswitch.table._ZN3pto18layout_type_to_strENS_10LayoutEnumE, 24

	.section	".linker-options","e",@llvm_linker_options
	.ident	"clang version 15.0.4 (linx64v5-musl-local 0509c2ca0c5525f7d7ffb6a34828b38b0d13922c)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym __cxx_global_var_init
	.addrsig_sym __cxx_global_var_init.4
	.addrsig_sym _ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE12defaultShapeE
	.addrsig_sym _ZN3pto12GlobalTensorIfNS_5ShapeILi1ELi1ELi1ELi1ELi1EEENS_6StrideILi1ELi1ELi256ELi256ELi1EEELNS_6LayoutE0EE13defaultStrideE
