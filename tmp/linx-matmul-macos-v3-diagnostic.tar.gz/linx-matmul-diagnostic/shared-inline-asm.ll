target triple = "linx64v5"

define void @shared_inline_asm_modifier() {
  %shared = call i64 asm sideeffect "C.B.IOS ${0:S}", "=@2Sr"()
  call void asm sideeffect "C.B.IOS ${0:S}", "@2Sr"(i64 %shared)
  ret void
}
