	.text
	.file	"shared-inline-asm.ll"
	.globl	shared_inline_asm_modifier      // -- Begin function shared_inline_asm_modifier
	.p2align	1
	.type	shared_inline_asm_modifier,@function
shared_inline_asm_modifier:             // @shared_inline_asm_modifier
	.cfi_startproc
.LBB0_1:
	//APP
	C.B.IOS	
	//NO_APP
.LBB0_2:
	//APP
	C.B.IOS	
	//NO_APP
.LBB0_3:
	C.BSTART.STD	RET
	c.setc.tgt	ra
	C.BSTART.STD	
.Lfunc_end0:
	.size	shared_inline_asm_modifier, .Lfunc_end0-shared_inline_asm_modifier
	.cfi_endproc
                                        // -- End function
	.section	".note.GNU-stack","",@progbits
